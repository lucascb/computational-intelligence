#!/usr/bin/env python3
# coding=utf-8

def euclidean_distance(p1, p2):
    return ((p1[0]-p2[0])**2 + (p1[1]-p2[1])**2) ** 0.5


class Graph(object):

    def __init__(self):
        self.map = []

    def load_from_matrix(self, filename):
        with open(filename, "r") as f:
            i = 0
            for line in f:
                if i > 0:
                    self.map.append(list(map(int, line.split())))
                i += 1

    def load_from_table(self, filename):
        pos = {}
        with open(filename, "r") as f:
            i = 0
            for line in f:
                if i == 0:
                    n = int(line)
                else:
                    x, y = line.split()
                    pos[i-1] = (float(x), float(y))
                i += 1
        self.map = [[0 for col in range(n)] for lin in range(n)]
        for i in range(n):
            for j in range(n):
                if i != j:
                    self.map[i][j] = euclidean_distance(pos[i], pos[j])
        #print(self.map)
